# n8n-nodes-baramundi - Quick Start Guide

**Version**: 0.1.0
**Package**: `n8n-nodes-baramundi-0.1.0.tgz` (102 KB)

---

## What's in This Package?

This distribution contains the **baramundi community node for n8n** - a powerful integration that enables workflow automation for baramundi Management Suite via the bConnect REST API.

### Key Features

- 🎯 **Smart Dropdowns** - Select endpoints, jobs, and OUs without looking up GUIDs
- 🔍 **Searchable Options** - Filter through hundreds of items instantly
- 🛡️ **12 Resource Types** - Comprehensive baramundi API coverage
- ✅ **Production Ready** - 633 tests, 86.35% coverage
- 📚 **Well Documented** - Complete guides and examples

### Included Files

```
n8n-baramundi-distribution/
├── n8n-nodes-baramundi-0.1.0.tgz  # npm package (102 KB)
├── QUICKSTART.md                   # This file
├── INSTALLATION.md                 # Detailed installation guide
├── README.md                       # Complete documentation
├── CHANGELOG.md                    # Version history
├── LICENSE.md                      # MIT license
└── TESTING_CHECKLIST.md            # Manual testing guide
```

---

## 5-Minute Installation

### Prerequisites

- ✅ n8n version 1.0.0 or higher
- ✅ Node.js 18.0.0 or higher
- ✅ baramundi Management Suite with bConnect API enabled

### Installation Steps

#### Option 1: From Tarball (Recommended for File Transfer)

```bash
# 1. Navigate to n8n custom directory
cd ~/.n8n/custom

# 2. Install from the tarball
npm install /path/to/n8n-nodes-baramundi-0.1.0.tgz

# 3. Restart n8n
pkill -f "n8n start"
n8n start
```

#### Option 2: From npm (If you have internet access)

```bash
# 1. Navigate to n8n custom directory
cd ~/.n8n/custom

# 2. Install from npm
npm install n8n-nodes-baramundi

# 3. Restart n8n
n8n restart
```

---

## First Steps After Installation

### 1. Verify Installation

Open n8n in your browser (`http://localhost:5678`) and search for "baramundi" when adding a node.

### 2. Configure Credentials

1. Go to **Credentials** → **Add Credential**
2. Search for "baramundi bConnect API"
3. Enter your connection details:
   - **Server URL**: `https://your-bms-server:444/bconnect`
   - **Username**: Your bConnect API username
   - **Password**: Your bConnect API password
   - **Ignore SSL Issues**: Enable if using self-signed certificates
4. Click **Test Credential** to validate
5. Click **Save**

### 3. Create Your First Workflow

**Example: List All Endpoints**

1. Create a new workflow
2. Add **Manual Trigger** node
3. Add **Baramundi** node
4. Configure:
   - **Credentials**: Select your baramundi credentials
   - **Resource**: `Endpoint`
   - **Operation**: `Get Many`
   - **Return All**: `true`
5. Click **Execute Workflow**
6. View your endpoints in the output panel

**Example: Execute a Job on an Endpoint**

1. Add another **Baramundi** node after the first
2. Configure:
   - **Resource**: `Job`
   - **Operation**: `Execute`
   - **Job Selection**: Click dropdown and search for your job
   - **Endpoint IDs**: Enter endpoint GUID or use expression from previous node
3. Click **Execute Workflow**
4. View job execution results

---

## Smart Dropdown Feature

The baramundi node includes intelligent dropdowns that make it easy to select resources:

### How to Use Dropdowns

1. When selecting an **Endpoint**, **Job**, or **Organizational Unit**:
   - Click the dropdown field
   - Browse up to 100 items loaded from your baramundi server
   - Use the search box to filter by name
   - Select your item

2. For advanced scenarios (expressions, dynamic values):
   - Select "**Enter Custom GUID...**" from the dropdown
   - Manually enter the GUID or use an expression

### Supported Operations with Dropdowns

**Endpoints** (6 operations):
- Get, Update, Delete, Start Enrollment

**Jobs** (6 operations):
- Get, Execute, Get Instances, Create Kiosk Release, Update, Delete

**Organizational Units** (2 operations):
- Get, Get Children

---

## Supported Resources

The node supports **12 resource types** with **50+ operations**:

| Resource Type               | Operations Available                          |
|-----------------------------|-----------------------------------------------|
| **Endpoints**               | Get, Get Many, Search, Update, Delete, Enroll |
| **Jobs**                    | Get, Get Many, Execute, Get Instances, etc.   |
| **Organizational Units**    | Get, Get Many, Get Children                   |
| **Software**                | Get Application, Get OS Installation, etc.    |
| **Mobile Devices**          | iOS/Android devices, Mobile apps              |
| **BitLocker**               | Get status, Manage encryption keys            |
| **SSH**                     | Deploy SSH keys                               |
| **VPP Licenses**            | Manage Apple VPP users and licenses           |
| **Inventory**               | Hardware/Software inventory, Custom attributes|
| **Compliance**              | View compliance violations                    |
| **Server Management**       | Server info, licenses, settings               |
| **Setup Integrity**         | Verify setup file hashes                      |

---

## Example Workflows

### 1. Daily Endpoint Compliance Check

```
Trigger (Cron: 0 8 * * *)
  → Baramundi: Get Many Endpoints
  → Code: Filter non-compliant endpoints
  → IF: Non-compliant found
  → Email: Send compliance report
```

### 2. Automated Software Deployment

```
Trigger (Webhook)
  → Baramundi: Search Endpoints (filter: new)
  → Baramundi: Execute Job (use dropdown to select deployment job)
  → Slack: Notify IT team
```

### 3. Job Execution Monitoring

```
Trigger (Every 5 minutes)
  → Baramundi: Get Job Instances (use dropdown to select job)
  → IF: Failed jobs found
  → PagerDuty: Create incident
```

---

## Troubleshooting

### Node Not Appearing

**Solution**:
```bash
cd ~/.n8n/custom
npm list n8n-nodes-baramundi
pkill -9 -f "n8n"
n8n start
```

### SSL Certificate Errors

**Solution**: Enable "Ignore SSL Issues" in credentials configuration

### Dropdown Not Loading

**Checklist**:
- ✅ Credentials configured and tested
- ✅ Network access to bConnect API
- ✅ API user has read permissions
- ✅ You can still use "Enter Custom GUID..." as fallback

---

## Documentation

For detailed information, see:

- **[INSTALLATION.md](INSTALLATION.md)** - Complete installation guide with Docker/npm options
- **[README.md](README.md)** - Full feature documentation and API reference
- **[TESTING_CHECKLIST.md](TESTING_CHECKLIST.md)** - Manual UI testing guide
- **[CHANGELOG.md](CHANGELOG.md)** - Version history and release notes
- **[LICENSE.md](LICENSE.md)** - MIT license and third-party licenses

---

## Getting Help

- **GitHub Issues**: https://github.com/baramundi-software/n8n-nodes-baramundi/issues
- **baramundi Support**: support@baramundi.com
- **n8n Community**: https://community.n8n.io

---

## Requirements Summary

| Component                      | Minimum Version | Tested Version |
|-------------------------------|-----------------|----------------|
| n8n                           | 1.0.0           | 1.71.0+        |
| Node.js                       | 18.0.0          | 20.x LTS       |
| baramundi bConnect API        | V1.1 or V2.0    | 2024           |

---

## What's Next?

After installation:

1. ✅ Configure baramundi credentials
2. ✅ Try the example workflows
3. ✅ Explore the 12 resource types
4. ✅ Use the smart dropdown feature
5. ✅ Read the full README for advanced features

---

**Package Version**: 0.1.0
**Release Date**: 2026-01-22
**License**: MIT
**Author**: baramundi software GmbH & Bernd Wiedemann

Happy Automating! 🚀
